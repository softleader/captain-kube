![](./docs/captainkube-01.svg)

> A command line tool for Kubernetes helps SoftLeader client deploying SoftLeader products

Documentation and Other Links:

- [Setup Documentation](https://github.com/softleader/captain-kube/wiki/Installation)
- [Usage Documentation](https://github.com/softleader/captain-kube/wiki/Getting-Started)
- [Manual Documentation](./docs/man/ckube.md)
